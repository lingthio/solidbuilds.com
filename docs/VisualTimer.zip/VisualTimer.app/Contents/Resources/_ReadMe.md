## History ##
- v0.1 - Aug 2025 - Initial version - timing based on onEverySecond()
- v0.2 - Aug 2025 - Added scheduled timers - timing based on now=Date()
- v0.3 - Aug 2025 - Added Calendar Events using EventKit. Added SettingsManager().
- v0.4 - Sep 2025 - Bug fixes.
- v0.5 - Oct 2025 - Modernized from ObservableObject to @Observable.

## Code organization
### View files
- AppViews.swift     - Main application window + AppState object
- SidebarViews.swift - Timer list views (calendar/scheduled/standard)
- DetailViews.swift  - Detail views (AccessPromt, Timer)

### Manager files
- CalendaManager.swift   - Manages Apple calandar and events
- TimerManager.swift     - Manages timer objects
- SettingsManager.swift  - Manages application settings
- UtilityFunctions.swift - Various utility functions

## Setup Apple Calendar ##
VisualTimer can not communicate with Google Calendar directly.
It relies instead on Apple Calendar's ability to connect various types of calendar accounts
(Google, Microsoft, Yahoo!, AOL, etc).

### Setting up Apple's Calendar app ###
Open Apple's Calendar app.
- From the main menu, select: Calendar > Settings > Accounts
- Click on the "+" icon (bottom left) and select "Google"
- Follow the prompts to authenticate the account.
- Close the settings window.

### Choosing your Google calendars ###
In the Apple Calendar app, the side panels should show a list of calendars.
- Select the calendars you want to show in VirtualTimer.
- Unselect the calendars you want to ignore in VirtualTimer.

### Configuring VisualTimer ###
Open the VisualTimer app.
- From the main menu, select: VisualTimer > Settings > Calendars
- Check the "Enable calendar event retrieval" checkbox
  - Grant VisualTimer full access to your Calendar
- Select the calendars you want to retrieve events from
- Unselect the calendars you want to ignore events from
- Close the settings window.

## Setup XCode ##
XCode > VisualTimer > Targets > VisualTimer > Signing and Capabilities
- Add Capability: "Hardened Runtime"
  - Enable "Calendar"
- App sandbox:
  - Enable "Calendar"
  
## Timer functions ##
- ShowTimerView publishes and receives an everySecond timer
  to update TimerObject.remainingTime and draw the visual timers
- AppView publishes and receives an everyFiveMinutes timer
  to fetch calendars+events and update calendar timers
  
## ToDo ##
- Add beeps
- Display waiting time and over time differently
- Future
  - free vs paid - feature set or limitation
